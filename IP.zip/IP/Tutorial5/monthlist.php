d<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Month Data</title>
    <link rel="stylesheet" href="css/styles.css">
    <script src="jquery-2.2.4.min.js"></script>
</head>
<body>
    <?php 
        $monthno=$_POST['month']
    ?>
<div class="wrapper" style="margin-top: 10%;">
    <div class="title">
        Month No is : <?php echo $monthno; ?>
    </div>

    <div class="form">
       <div class="inputfield">
       <select id="month" name="month" class="inputfield input" required>
			<option <?php if($monthno==1) echo "selected" ?> >January</option>
			<option <?php if($monthno==2) echo "selected" ?>>Febuary</option>
			<option <?php if($monthno==3) echo "selected" ?>>March</option>
			<option <?php if($monthno==4) echo "selected" ?>>April</option>
			<option <?php if($monthno==5) echo "selected" ?>>May</option>
			<option <?php if($monthno==6) echo "selected" ?>>June</option>
			<option <?php if($monthno==7) echo "selected" ?>>July</option>
			<option <?php if($monthno==8) echo "selected" ?>>August</option>
			<option <?php if($monthno==9) echo "selected" ?>>September</option>
			<option <?php if($monthno==10) echo "selected" ?>>October</option>
			<option <?php if($monthno==11) echo "selected" ?>>November</option>
			<option <?php if($monthno==12) echo "selected" ?>>December</option>
		</select>
      </div>  
       <a href="index.php">Want to Select more..</a><br><br>
   </div>	
</body>
</html> 