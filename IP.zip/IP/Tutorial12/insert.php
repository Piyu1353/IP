<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tutorial 12</title>
  <!-- CSS only -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <!-- JavaScript Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
</head>

<body>
  <div class="container mt-4">
    <div class="row">
      <h2 class="text-center">Tutorial 12</h2>
      <form action="add.php" method="post">
        <label for="email" class="form-label">Machine Id</label>
        <div class="form-group">
          <input type="text" class="form-control" name="machine_id" placeholder="Machine Id">
        </div>

        <label for="email" class="form-label">Process Id</label>
        <div class="form-group">
          <input type="text" class="form-control" name="process_id" placeholder="Process Id">
        </div>

        <label for="email" class="form-label">Item Id</label>
        <div class="form-group">
          <input type="text" class="form-control" name="item_id" placeholder="Item Id">
        </div>

        <label for="email" class="form-label">Parameter Name</label>
        <div class="form-group">
          <input type="text" class="form-control" name="parametername" placeholder="Parameter Name">
        </div>

        <label for="email" class="form-label">Lower Tolerance</label>
        <div class="form-group">
          <input type="text" class="form-control" name="lower_tolerance" placeholder="Lower Tolerance">
        </div>

        <label for="email" class="form-label">Upper Tolerance</label>
        <div class="form-group">
          <input type="text" class="form-control" name="upper_tolerance" placeholder="Upper Tolerance">
        </div>

        <label for="email" class="form-label">Item Name</label>
        <div class="form-group">
          <input type="text" class="form-control" name="item_name" placeholder="Item Name">
        </div>

        <label for="email" class="form-label">Machine Name</label>
        <div class="form-group">
          <input type="text" class="form-control" name="machine_name" placeholder="Machine Name">
        </div>

        <label for="email" class="form-label">Process Name</label>
        <div class="form-group">
          <input type="text" class="form-control" name="process_name" placeholder="Process Name">
        </div>

        <div class="mt-3 mb-3">
          <button type="submit" name="submit" class="btn btn-primary">Submit</button>
          <a class="btn btn-danger" onclick="history.back()">Delete</a>
        </div>
      </form>
    </div>
  </div>
</body>

</html>