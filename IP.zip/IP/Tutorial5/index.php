<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Month Data</title>
    <link rel="stylesheet" href="css/styles.css">
    <script src="jquery-2.2.4.min.js"></script>
</head>
<body>
   
<div class="wrapper" style="margin-top: 10%;">
    <div class="title">
        Month List
    </div>
    <form action="monthlist.php" method="post">
        <div class="form">
            <div class="inputfield">
                <select id="month" name="month" class="inputfield input"  required>
                    <option value="">-- Select Number --</option>
                    <option value="1">Month No. 1</option>
                    <option value="2">Month No. 2</option>
                    <option value="3">Month No. 3</option>
                    <option value="4">Month No. 4</option>
                    <option value="5">Month No. 5</option>
                    <option value="6">Month No. 6</option>
                    <option value="7">Month No. 7</option>
                    <option value="8">Month No. 8</option>
                    <option value="9">Month No. 9</option>
                    <option value="10">Month No. 10</option>
                    <option value="11">Month No. 11</option>
                    <option value="12">Month No. 12</option>
                </select>
            </div>  
            <div class="inputfield">
                <input type="submit" name="calculate" value="Submit" class="btn" id="login">
            </div> 
        </div>
    </form>	
</body>
</html>