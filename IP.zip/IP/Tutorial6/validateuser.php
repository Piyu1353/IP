<?php session_start(); /* Starts the session */

/* Check Login form submitted */	
if(isset($_POST['signin'])){
   
    /* Check and assign submitted username and password to new variable */
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    
    if($username == 'Priyanshi'  && $password == '123456'){
        $_SESSION['username']=$username;
        header('location:index.php');
    }
    else{
        echo '<script>alert("Email & password is Incorrect");</script>';
        echo '<script type="text/javascript">';
        echo 'window.location.href="login.php"';
        echo '</script>';
    }
}
else{
}
?>    