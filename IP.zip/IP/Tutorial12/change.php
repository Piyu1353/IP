<?php
    session_start();
    include("conn/conn.php");

     $id=isset($_POST['id'])?$_POST['id']:0;
     $machine_id=isset($_POST['machine_id'])?$_POST['machine_id']:0;
     $process_id=isset($_POST['process_id'])?$_POST['process_id']:0;
     $item_id=isset($_POST['item_id'])?$_POST['item_id']:0;
     $machine_name=isset($_POST['machine_name'])?$_POST['machine_name']:"";
     $process_name=isset($_POST['process_name'])?$_POST['process_name']:"";
     $item_name=isset($_POST['item_name'])?$_POST['item_name']:"";
     $parametername=isset($_POST['parametername'])?$_POST['parametername']:"";
     $lower_tolerance=isset($_POST['lower_tolerance'])?$_POST['lower_tolerance']:"";
     $upper_tolerance=isset($_POST['upper_tolerance'])?$_POST['upper_tolerance']:"";

     "<br>";
     $sql="UPDATE tbl_machine set machine_name ='$machine_name' WHERE id=$machine_id";
     "<br>";
     $sql2="UPDATE tbl_process set process_name='$process_name' where id=$process_id";
     "<br>";
     $sql3="UPDATE tbl_items set item_name ='$item_name' WHERE id=$item_id";
     "<br>";
     $sql4="UPDATE tbl_ipmp set parametername ='$parametername' WHERE id=$id";
     "<br>";
     $sql5="UPDATE tbl_ipmp set lower_tolerance ='$lower_tolerance' WHERE id=$id";
     "<br>";
     $sql6="UPDATE tbl_ipmp set upper_tolerance ='$upper_tolerance' WHERE id=$id";
    $result=$db->query($sql);
    $result2=$db->query($sql2);
    $result3=$db->query($sql3);
    $result4=$db->query($sql4);
    $result5=$db->query($sql5);
    $result6=$db->query($sql6);
    if($db->affected_rows)
    {
        //  $db->affected_rows
        $_SESSION['update']="Record update";
    }
    header("location:index.php");
?>