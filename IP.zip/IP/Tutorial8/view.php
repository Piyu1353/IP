<?php  require "include/connection.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Pictures</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
        .alb{
            display: inline-block;
            width: 250px;
            height: 200px;
            padding: 5px;
        }
        .alb img{
            width: 100%;
            height: 100%;
        }
        a{
            text-decoration:none;
            color:black;
            
        }
        .backtosite{
                    color: black;
                    font-size: 25px;
                    text-align: center;
                    text-decoration: underline;
                }           
    </style>
</head>
<body>
<p class="backtosite"> 
    <a href="index.php" class="backtosite"> Want to Upload more Photos?</a>
</p>
    <?php
        $sql = "SELECT * FROM images ORDER BY id DESC";
        $res = mysqli_query($db, $sql);

        if(mysqli_num_rows($res) > 0)
        {
            while($images = mysqli_fetch_assoc($res)){ ?>
        
                <div class="alb">
                    <img src="upload/<?=$images['image_url']?>">
                </div>

        <?php } } ?>
</body>
</html>