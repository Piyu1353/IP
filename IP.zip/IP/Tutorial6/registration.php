<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REGISTRATION</title>
    <link rel="stylesheet" href="css/styles.css">
    <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet' type='text/css'>
    <script src="jquery-2.2.4.min.js"></script>
</head>
<body>
    <div class="login">
        <h1> sign up </h1>
        <form action="#" method="post" id="registration">
            <br>
            <input type="text" id="fname" class="eff" name="fname" placeholder="Enter Full Name">
            <input type="email" id="email" class="eff" name="email" placeholder="Enter Email">
            <input type="password" id="password" class="eff" name="password" placeholder="Enter Password">
            <input type="password" id="repassword" class="eff" name="rpassword" placeholder="Enter Re-Password">
            <input type="number"  id="age" name="age" class="form-control eff ex" placeholder="Age">&ensp;
            <input type="date" id="date" name="date" style="color:#6c757d" class="form-control eff ex" placeholder="Date of Birth">
            <br>
            <select id="country" class="my-menu">
                <div slot="listbox">
                    <div popup="popup" behavior="listbox">
                        <option>------Country------</option>
                        <option>India</option>
                        <option>USA</option>
                        <option>Austria</option>
                        <option>Bhutan</option>
                        <option>Canada</option>
                        <option>Germany</option>
                        <option>Japan</option>
                    </div>
                </div>
            </select>&nbsp;&nbsp;
            <select id="state" class="my-menu">
                <div slot="listbox">
                    <div popup="popup" behavior="listbox">
                        <option>----State----</option>
                        <option>Maharashtra</option>
                        <option>Gujarat</option>
                        <option>Rajsthan</option>
                        <option>Kerala</option>
                        <option>UP</option>
                        <option>Kashmir</option>
                    </div>
                </div>
            </select>&nbsp;&nbsp;
            <select id="city" class="my-menu">
                <div slot="listbox">
                    <div popup="popup" behavior="listbox">
                        <option>Select car:</option>
                        <option>Mumbai</option>
                        <option>Rajkot</option>
                        <option>Nagpur</option>
                        <option>Ahmdabad</option>
                        <option>Jaipur</option>
                        <option>Delhi</option>
                        <option>Chandigarh</option>
                    </div>
                </div>
            </select>
            <input type="file" class="eff" id="pic" name="pic">
            <br>
            <input type="submit" class="signin" value="Sign UP">
            <hr>            
            <p>Already have an account?&ensp;<a href="login.html">Sign IN</a></p><br>
        </form>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript">
        jQuery.validator.addMethod("noSpace", function(value, element) { 
        return value == '' || value.trim().length != 0;  
    }, "No space please and don't leave it empty");
    jQuery.validator.addMethod("customEmail", function(value, element) { 
    return this.optional( element ) || /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test( value ); 
    }, "Please enter valid email address!");
    $.validator.addMethod( "alphanumeric", function( value, element ) {
    return this.optional( element ) || /^\w+$/i.test( value );
    }, "Letters, numbers, and underscores only please" );
    var $registrationForm = $('#registration');
    if($registrationForm.length){
    $registrationForm.validate({
        rules:{
            //fname is the name of the textbox
            fname: {
                required: true,
                //alphanumeric is the custom method, we defined in the above
                alphanumeric: true
            },
            email: {
                required: true,
                customEmail: true
            },
            password: {
                required: true
            },
            rpassword: {
                required: true,
                equalTo: '#password'
            },
            
            age: {
                required: true
            },
            date: {
                required: true
            },
            country: {
                required: true
            },
            state: {
                required: true
            },
            city: {
                required: true
            },
            pic: {
                required: true
            }
        },
        messages:{
            fname: {
                //error message for the required field
                required: 'Please enter fname!'
            },
            email: {
                required: 'Please enter email!',
                //error message for the email field
                email: 'Please enter valid email!'
            },
            password: {
                required: 'Please enter password!'
            },
            rpassword: {
                required: 'Please enter confirm password!',
                equalTo: 'Please enter same password!'
            },
            
            age: {
                required: 'Please enter age!'
            },
            date: {
                required: 'Please select Date!'
            },
            country: {
                required: 'Please select country!'
            },
            state: {
                required: 'Please select State!'
            },
            city: {
                required: 'Please select city!'
            },
            pic: {
                required: 'Please select file!'
            }
        }
    });
    }
    </script>
</body>
</html>
