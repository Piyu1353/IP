<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title> calculate interest</title>
    <style type="text/css">
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700;900&display=swap');

        *, body {
            font-family: 'Poppins', sans-serif;
            font-weight: 400;
            -webkit-font-smoothing: antialiased;
            text-rendering: optimizeLegibility;
            -moz-osx-font-smoothing: grayscale;
            color: black;
        }
        html, body {
            height: 100%;
            background: linear-gradient(to bottom, #ffffff 0%, #ff6699 100%);
        }
        h1{
            text-align: center;
        }
        .btn
        {
            color: black;
            background: linear-gradient(to bottom, #ff6666 0%, #ff0066 100%);
            border-style: none;
            text-decoration: none;
            /*box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);*/
        }

        .btn:hover {
        box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
        
        text-decoration: none;
        border: none;
        }

        label{
        font-size: 15px; 
        }
        .container{
            align-content: center;
            padding-left:20% ;
            padding-right: 20%;
        }
        .f{
            border: none;
            box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
            background: white;
        }
        .f1{
            padding: 10%;
        }
    </style>

    
</head>
<body>
    <div class="container">
   
        <h1>calculate interest</h1>
        <div class="f">

        <form action="result.php" method = "GET" class="f1">
            <div class="form-group ">
                <label for="principal ">Enter Principal Amount:</label>
                <input type="number" name="principal" id="principal"class="form-control">
            </div>
            <div class="form-group ">
                <label for="interest">Enter Rate of Interest:</label>
                <input type="number" name="interest" id="interest" class="form-control">
            </div>
            <div class="form-group">
                <label for="year">Enter Number of Year:</label>
                <input type="number" name="year" id="year" class="form-control">
            </div>
            <div class="form-group">
                <input type="submit"class="form-control btn" value="Calculate">
               <!-- <button type="submit" class="btn ">calculate</button>-->
            </div>

        </form>
        </div>
        
    </div>
    
</body>
</html>