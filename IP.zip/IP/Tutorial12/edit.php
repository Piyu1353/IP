<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tutorial 12</title>
  <!-- CSS only -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <!-- JavaScript Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
</head>

<body>
  <div class="container mt-4">
    <div class="row">
      <h2 class="text-center">Tutorial 12</h2>
      <form action="change.php" method="post">
        <input type="hidden" class="form-control" placeholder="machine_name:" name="id" value="<?= $_GET['id'] ?>">
        <input type="hidden" class="form-control" placeholder="machine_name:" name="machine_id" value="<?= $_GET['machine_id'] ?>">
        <input type="hidden" class="form-control" placeholder="machine_name:" name="process_id" value="<?= $_GET['process_id'] ?>">
        <input type="hidden" class="form-control" placeholder="machine_name:" name="item_id" value="<?= $_GET['item_id'] ?>">

        <label for="email" class="form-label">Machine Name</label>
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Machine Name" name="machine_name" value="<?= $_GET['machine_name'] ?>">
        </div>

        <label for="email" class="form-label">Process Name</label>
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Process Name" name="process_name" value="<?= $_GET['process_name'] ?>">
        </div>

        <label for="email" class="form-label">Item Name</label>
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Item Name" name="item_name" value="<?= $_GET['item_name'] ?>">
        </div>

        <label for="email" class="form-label">Parameter Name</label>
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Parameter Name" name="parametername" value="<?= $_GET['parametername'] ?>">
        </div>

        <label for="number" class="form-label">Lower Tolerance</label>
        <div class="form-group">
          <input type="number" step="0.01" class="form-control" placeholder="Lower Tolerance" name="lower_tolerance" value="<?= $_GET['lower_tolerance'] ?>">
        </div>

        <label for="number" class="form-label">Upper Tolerance</label>
        <div class="form-group">
          <input type="number" step="0.01" class="form-control" placeholder="Upper Tolerance" name="upper_tolerance" value="<?= $_GET['upper_tolerance'] ?>">
        </div>

        <div class="mt-3 mb-3">
          <button type="submit" name="submit" class="btn btn-primary">Submit</button>
          <a class="btn btn-danger" onclick="history.back()">Cancel</a>
        </div>
      </form>
    </div>
  </div>
</body>

</html>