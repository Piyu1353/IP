<?php

	$connection=new mysqli("localhost","root","","clubuvdb");

	if ($connection->connect_error) {
		echo $connection->connect_error; 
	}

?>