<!DOCTYPE html>
<html lang="en" >
<head>
    <meta charset="UTF-8">
    <title>LOGIN</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- partial:index.partial.html -->
    <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet' type='text/css'>

    <div class="login">
        <h1> sign in </h1>
        <form action="validateuser.php" method="post" class="loginf">
            <input type="text" class="eff" name="username" placeholder="Enter Username" required>
            <br>
            <input type="password" class="eff" name="password" placeholder="Enter Password" required>
            <br><br>
            <input type="submit" class="signin" value="Sign In" name="signin">

            <input type="checkbox" id="checkbox-1-1" class="custom-checkbox" />
            <label class="l" for="checkbox-1-1">Keep me Signed in</label>
            <hr>
            <p>Don't have an account?&ensp;<a href="registration.php">Sign UP</a></p><br>
        </form>
    </div>
</body>
</html>
