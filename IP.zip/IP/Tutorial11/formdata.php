<?php
    session_start();
    include("conn.php");

    $id = isset($_GET['id'])? $_GET['id'] : 0;

    $sql = "SELECT machine_name,description FROM tbl_machine where id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows) {
        $row = $result->fetch_assoc();
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Edit Data</title>
    <style>
        body{
            background-color: #e74c3c;
        }
        .container{
            margin-top: 60px;
            width: 45%;
            height:100%;
            background: white;
            font-family: Arial, Helvetica, sans-serif;
            letter-spacing:1.5px;
            box-shadow:0 0 50px #ffffff,0 0 40px #ffffff;
        }
        .form-group{
            margin-left: 45px;
        }
        .form-control{
            margin-left: 45px;
            width: 100%;
        }
        .lbl{
            color: #b9bbb6;
        }
        label{
            font-size: 21px;
        }
        .h{
            text-align: center;
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <form method="post" action="savedata.php">
            <h2 class="mt-4 mb-4 h">Machine Details</h2>
            <input type="hidden" name="id" value="<?= $id ?>"></input>
            <?php
                if($_GET['a']){
            ?>
                    <div class="form-group col-8">
                        <label>Machine ID:</label>
                        <label class="form-control mt-2 mb-4 lbl"><?= $id ?></label>
                    </div>
            <?php
                }
            ?>
            <div class="form-group col-8">
                <label>Machine Name:</label>
                <input type="text" class="form-control mt-2 mb-4" name="machinename" value="<?= isset($row['machine_name']) ? $row['machine_name'] : "" ?>">
            </div>
            <div class="form-group col-8">
                <label>Description:</label>
                <input type="text" class="form-control mt-2 mb-4" name="description" value="<?= isset($row['description']) ? $row['description'] : "" ?>">
            </div>
            <center><button type="submit" class="btn btn-primary btn-lg mb-4">Submit</button></center>
        </form>
    </div>
</body>
</html>