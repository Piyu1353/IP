<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Result</title>
    <style>
        body{
            background-image: linear-gradient(to top left, orange, purple);
            background-size: 1366px 657px;
            background-repeat: no-repeat;
        }
        .container{
            align-content: center;
            padding-left:20% ;
            padding-right: 20%;
        }
        .good{ 
            background: red;
            border: none;
            box-shadow: 0 12px 16px 0 rgba(1,1,1,0.24),0 17px 50px 0 rgba(19,10,10,0.19);
            background: white;
            padding: 8%;
        }
		a:link,a:visited{
			text-decoration: none;
			color: cornflowerblue;
            font-size: 20px;
		}
        a:hover{
            animation:blinkingText 0.4s infinite;
            font-size: 24px;
        }
        @keyframes blinkingText{
            0%{color: cornflowerblue;}
            49%{color: cornflowerblue}
            60%{color: purple;}
            99%{color:orange;}
            100%{color: orange}
        }
        label{
            font-family: Calibri;
            font-size: 26px;
            color: purple;
        }
        h1{
            color: white;
            text-align: center;
            font-weight: bold;
        }
        .link{
            text-align: center;
        }
    </style>
</head>
<body>
    <!--top bottom right left-->
    <div class="container">
        <h1>Calculate Interest</h1>
        <div class="good">
            <?php
                $p=$_REQUEST['principal'];
                $r=$_REQUEST['rate'];
                $n=$_REQUEST['noy'];
                $i=($p*$r*$n)/100;
            ?>
        
            <div class="form-group">
                <label>Principal Amount:-<?php echo "$p"; ?></label>
            </div>
            <div class="form-group">
                <label>Rate of Interest:- <?php echo "$r"; ?></label>
            </div>
            <div class="form-group">
                <label>No. of Years:- <?php echo "$n"; ?></label>
            </div>
            <div class="form-group">
                <label>Total Interest is:- <?php echo "$i"; ?></label>
            </div>
			<div class="link"><a href="index.php">Want to Calculate more...</a></div>
			<div class="link"><a href="../../index.php">Back to Website!</a></div>
		</div>
        </div>
    </div>
</body>
</html>

