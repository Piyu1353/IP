<?php session_start(); 

if(!isset($_SESSION['username']))
{
   header('location:login.php');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Data</title>
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
            <style>
                body{
                    background-color: #e74c3c;
                }
                .table{
                    margin-top: 30px;
                    width: 90%;
                    height:100%;
                    background: #fcc9b4;
                    font-family: Arial, Helvetica, sans-serif;
                    letter-spacing:1.5px;
                }
                div{
                    font-size: 20px;
                }
                .p{
                    text-align: center;
                    font-size: 20px;
                    font-weight: bold;
                    text-decoration: underline;
                }
            </style>
</head>
<body>
    <table class="table table-hover table-bordered" align="center">
        <thead>
            <tr>
                <td colspan=10 class="p">Registration data</td>
            </tr>
            <tr>
                <td colspan=10>
                    <a href="logout.php" class="btn btn-danger float-right ml-2">Log Out</a>
                    &emsp;
                    <a href="" class="btn btn-primary float-right">Add</a>
                </td>
            </tr>
            <tr>	
                <th>Sr.</th>	
                <th>Name</th>	
                <th>Email</th>	
                <th>Enrollment</th>
                <th>Action</th>
            </tr>
        </thead>
        <tr>
            <th>1</th>
            <td>Rajesh Joshi</td>
            <td>rajesh@gmail.com</td>
            <td>20SOECE11011</td>
            <td>
                <a href="" class="btn btn-outline-success">EDIT</a>
                <a href="" class="btn btn-outline-danger">DELETE</a>
            </td>
        </tr>
        <tr>
            <td>2</td>
            <td>Priyanshi Padariya</td>
            <td>piyu13@gmail.com</td>
            <td>21SOECE13052</td>
            <td>
                <a href="" class="btn btn-outline-success">EDIT</a>
                <a href="" class="btn btn-outline-danger">DELETE</a>
            </td>
        </tr>
        <tr>
            <td>3</td>
            <td>Aneri Padariya</td>
            <td>anu12@gmail.com</td>
            <td>22SOECE13052</td>
            <td>
                <a href="" class="btn btn-outline-success">EDIT</a>
                <a href="" class="btn btn-outline-danger">DELETE</a>
            </td>
        </tr>
        
    </table>
</body>
</html>
