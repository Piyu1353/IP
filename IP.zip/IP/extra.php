<?php
    // If we are include any php file to in this file that time we have to write this code.
    // include("connnection.php");
    // include("retrive.php");
?>
<?php
	$db=new mysqli("localhost","root","","tutorial10");
	if($db->connect_errno){
		echo $db->connect_error;
	}
    else
    {
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Data Selected</title>
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
            <style>
                body{
                    background-color: #e74c3c;
                }
                .table{
                    margin-top: 30px;
                    width: 90%;
                    height:100%;
                    background: #ffa07a;
                    font-family: Arial, Helvetica, sans-serif;
                    letter-spacing:1.5px;
                    box-shadow:0 0 50px #ffffff,0 0 40px #ffffff;
                }
                div{
                    font-size: 20px;
                }
                .p{
                    text-align: center;
                    font-size: 20px;
                    font-weight: bold;
                    text-decoration: underline;
                }
            </style>
        </head>
        <body>
            <div class="container">
            <?php
                session_start();
                if(isset($_SESSION['deletemsg']))
                {
            ?>
                <div class="text-success">
                    <?php 
                        echo $_SESSION['deletemsg'];
                        unset ($_SESSION['deletemsg']);
                    ?>
                </div>
            <?php
                }
            ?>
            
                <table class="table table-hover table-striped" align="center">
                    <thead>
                    <td colspan=4 class="p">Machine Details</td>
                    <?php
                        $q = "
                        Select
                            id,
                            machine_name,
                            description
                        from
                            tbl_machine
                        where
                            is_Delete = 0
                            and
                            machine_name like 'dr%'
                        order by
                            machine_name desc
                        limit
                            21,100";
                        //echo $q;
                        $res=$db->query($q);
                        if($res->num_rows){
                    ?>
                            <tr>
                                <th>ID</th>
                                <th>Machine Name</th>
                                <th>Description</th>
                                <th></th>
                    
                            </tr>
                        </thead>
                    <?php
                        while($row = $res->fetch_assoc()){
                    ?>
                        <tr>                            
                            <td><?=$row['id']?></td>
                            <td><?=$row['machine_name']?></td>
                            <td><?=$row['description']?></td>
                            <td>
                                <a href="" class="btn btn-warning">EDIT</a>&nbsp;
                                <a href="deletedata.php?id=<?=$row['id']?>" class="btn btn-danger">DELET</a>
                            </td>
                        </tr>
                    <?php    
                        }
                    }else{
                    ?>
                    <tr>
                            <td colspan="2">No record found.</td>
                    </tr>
                    <?php
                    }
                    ?>
                </table>
            </div>
        </body>
        </html>
<?php
    }
?>