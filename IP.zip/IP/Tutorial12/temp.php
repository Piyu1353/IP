<?php
    session_start();
    include("conn/conn.php");

     $id=isset($_GET['id'])?$_GET['id']:0;
     $machine_id=isset($_GET['machine_id'])?$_GET['machine_id']:0;
     $process_id=isset($_GET['process_id'])?$_GET['process_id']:0;
     $item_id=isset($_GET['item_id'])?$_GET['item_id']:0;
     "<br>";
     $sql="UPDATE tbl_machine set is_delete =1 WHERE id=$machine_id";
     "<br>";
     $sql2="UPDATE tbl_process set is_delete=1 where id=$process_id";
     "<br>";
     $sql3="UPDATE tbl_items set is_delete =1 WHERE id=$item_id";
     "<br>";
     $sql4="UPDATE tbl_ipmp set is_delete =1 WHERE id=$id";
    $result=$db->query($sql);
    $result2=$db->query($sql2);
    $result3=$db->query($sql3);
    $result4=$db->query($sql4);
    if($db->affected_rows)
    {
        $_SESSION['deletemessage']="Record Deleted";
    }
    header("location:index.php");
?>