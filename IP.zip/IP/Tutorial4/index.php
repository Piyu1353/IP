<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Calculate</title>
    <style>
        body{
            background-image: linear-gradient(to top left, orange, purple);
            background-size: 1366px 657px;
            background-repeat: no-repeat;
        }
        .container{
            align-content: center;
            padding-left:20% ;
            padding-right: 20%;
        }
        .good{
            border: none;
            box-shadow: 0 12px 16px 0 rgba(1,1,1,0.24),0 17px 50px 0 rgba(19,10,10,0.19);
            background: white;
        }
        .form{
            padding: 8%;
        }
        .btn{
            font-family: Calibri;
            font-size: 24px;
            color: white;
            border-color: black;
            background-image: linear-gradient(to top left, purple, orange);
            width: 100%;
            align: center;
        }
        label{
            font-family: Calibri;
            font-size: 24px;
            color: black;
        }
        h1{
            color: white;
            text-align: center;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <!top bottom right left>
    <div class="container">
        <h1>Calculate Interest</h1>
        <div class="good">
            <form action="result.php" method="POST" class="form">
                <div class="form-group">
                    <label for="principal">Principal Amount:</label><br>
                    <input type="number" name="principal" id="principal" class="form-control">
                </div>
                <div class="form-group">
                    <label for="rate">Rate of Interest:</label><br>
                    <input type="number" name="rate" id="rate" class="form-control">
                </div>
                <div class="form-group">
                    <label for="noy">No. of Years:</label><br>
                    <input type="number" name="noy" id="noy" class="form-control">
                </div>
                <div class="form-group">
                    <input type="submit" value="Calculate" class="btn btn-primary">
                </div>
            </form>
        </div>
    </div>
</body>
</html>