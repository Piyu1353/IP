<?php
    if(isset($_POST['submit']))
    {
    include("conn/conn.php");
    session_start();
    $machine_id=$_POST["machine_id"];
    $process_id=$_POST["process_id"];
    $item_id=$_POST["item_id"];
    $parametername=$_POST["parametername"];
    $lower_tolerance=$_POST["lower_tolerance"];
    $upper_tolerance=$_POST["upper_tolerance"];
    $is_delete=0;
    $item_name=$_POST['item_name'];
    $machine_name=$_POST['machine_name'];
    $process_name=$_POST['process_name'];
    $sql="INSERT INTO `tbl_ipmp`(`machine_id`, `process_id`, `item_id`, `parametername`, `lower_tolerance`, `upper_tolerance`, `is_delete`) VALUES ($machine_id,$process_id,$item_id,'$parametername',$lower_tolerance,$upper_tolerance,$is_delete)";
    $sql2="INSERT INTO `tbl_items`(`item_name`) VALUES ('$item_name');";
    $sql3="INSERT INTO `tbl_machine`(`machine_name`) VALUES ('$machine_name');";
    $sql4="INSERT INTO `tbl_process`( `process_name`) VALUES ('$process_name');";
    echo $sql;  
    if($db->query($sql)===TRUE&&$db->query($sql2)===TRUE&&$db->query($sql3)===TRUE&&$db->query($sql4)===TRUE)
    {
        $_SESSION['add']="New record created successfully";
    }
    else {
        echo "Error: " . $sql . "<br>" . $conn->error;
      }
      header("location:index.php");
    }
    
?>