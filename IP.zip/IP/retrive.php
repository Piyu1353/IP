<?php
    $q = "
        Select
            id,
            machine_name,
            description
        from
            tbl_machine
        where
            is_Delete = 0
            and
            machine_name like 'dr%'
        order by
            machine_name desc
        limit
            21,100";
    //echo $q;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Selected</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
        body{
            background-color: #e74c3c;
        }
        .table{
            width: 70%;
            height:100%;
            background: #ffa07a;
            font-family: Arial, Helvetica, sans-serif;
            border-radius: 20px;
            border-color: black;
            letter-spacing:1.5px;
            box-shadow:0 0 50px #ffffff,0 0 40px #ffffff;
        }
    </style>
</head>
<body>
    <table class="table table-hover" align="center">
        <?php
        $res=$db->query($q);
        if($res->num_rows){?>
        <tr>
            <th>ID</th>
            <th>Machine Name</th>
            <th>Description</th>
        </tr>
        <?php
            while($row = $res->fetch_assoc()){
        ?>
            <tr>
                <td><?=$row['id']?></td>
                <td><?=$row['machine_name']?></td>
                <td><?=$row['description']?></td>
            </tr>
        <?php    
            }
        }else{
        ?>
        <tr>
                <td colspan="2">No record found.</td>
        </tr>
        <?php
        }
        ?>
    </table>
</body>
</html>

    