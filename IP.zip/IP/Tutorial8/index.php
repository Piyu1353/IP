<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="include/styles.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Tutorial 08</title>

    
</head>
<body>
<div class="wrapper" style="margin-top: 10%;">
    <?php if(isset($_GET['error'])){?>
        <p style="color:red"> <?php echo $_GET['error']; ?></p>
    <?php } ?>
    <div class="title">
        Select Picture
    </div>
    <form action="upload.php" method="POST" enctype="multipart/form-data">
        <div class="form">
            <div class="inputfield">
                <div class="form-group">
                    <div class="col-md-12">
                        <input type="file" name="my_image" class="file"/>
                    </div>
                </div>
                
            </div>  
            <div class="inputfield">
                <div class="button">
                    <input type="submit" class="btn btn-info" name="submit" value="Upload"/><br>
                    <a href="view.php" class="btn" name="view" value="View">View</a>
                </div>
            </div> 
        </div>
    </form>	    
</body>
</html>




