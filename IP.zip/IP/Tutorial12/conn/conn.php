<?php
    $db=new mysqli("localhost","root","","tutorial12");
    
    //"localhost","root","","tutorial12"
    
    if($db->connect_error)
    {
        echo $db->connect->error;
        // echo "hello";
    }
    else
    {
        // echo "connection done ";
    }
?>