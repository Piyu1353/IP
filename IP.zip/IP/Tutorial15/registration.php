<?php

  include('include/header.php');

  $pass = isset($_SESSION['password']) ? $_SESSION['password'] : "";
  unset($_SESSION['password']);

  $fileerror = isset($_SESSION['fileerror']) ? $_SESSION['fileerror'] : "";
  unset($_SESSION['fileerror']);

?>
<!DOCTYPE html>
<html lang="en" >
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REGISTRATION</title>
    <link rel="stylesheet" href="css/styles.css">
    <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet' type='text/css'>
    <script src="jquery-2.2.4.min.js"></script>
</head>
<body>
    <div class="login">
        <h1> sign up </h1>
        <form action="store.php" method="post" id="form">
            <h3 class="text-danger"><?=$pass?></h3>
            <h2 class="text-danger"><?=$fileerror?></h2>
            <br>
            <input type="text" id="fullname" class="eff" name="fullname" placeholder="Enter Full Name">
            <input type="text" id="firstname" class="eff" name="firstname" placeholder="Enter First Name">
            <input type="text" id="lastname" class="eff" name="lastname" placeholder="Enter Last Name">
            <input type="email" id="email" class="eff" name="email" placeholder="Enter Email">
            <input type="password" id="pswd" class="eff" name="pswd" placeholder="Enter Password">
            <input type="password" id="cpswd" class="eff" name="cpswd" placeholder="Enter Re-Password">
            <input type="tel"  id="contact" name="contact" class="form-control eff" placeholder="Enter Contact">&ensp;
            <label for="date" class="lable" >Birth Date:</label>
            <input type="date" id="bdate" name="bdate" style="color:#6c757d" class="form-control eff ex" placeholder="Date of Birth">
            <br>
            <select id="gender" class="my-menu" name="gender">
                <div slot="listbox">
                    <div popup="popup" behavior="listbox">
                        <option>Select Gender</option>
                        <option>Male</option>
                        <option>Female</option>
                        <option>Other</option>
                    </div>
                </div>
            </select>
            <input type="file" class="eff" id="photo" name="photo">
            <br>
            <input type="submit" class="signin" value="Sign UP" name="register">
            <hr>            
            <p>Already have an account?&ensp;<a href="login.php">Sign IN</a></p><br>
        </form>
    </div>
    </body>
</html>