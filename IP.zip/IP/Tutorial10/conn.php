<?php

    // $username = "root";
    // $password = "";
    // $db = "tutorial10";

    $conn = new mysqli("localhost", "root", "", "tutorial10");


    if ($conn->connect_error) 
    {
        die("Connection failed: " . $conn->connect_error);
    }
    
    // echo "Connected successfully";        
?>