<?php
    // If we are include any php file to in this file that time we have to write this code.
    // include("connnection.php");
    // include("retrive.php");
?>
<?php
	include("conn.php")
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Selected</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
        body{
            background-color: #e74c3c;
        }
        .table{
            margin-top: 30px;
            width: 100%;
            height:100%;
            background: white;
            font-family: Arial, Helvetica, sans-serif;
            letter-spacing:1.5px;
            box-shadow:0 0 50px #ffffff,0 0 40px #ffffff;
        }
        div{
            font-size: 20px;
        }
        .p{
            text-align: center;
            font-size: 28px;
            font-weight: bold;
            text-decoration: underline;
            height:70px;
            padding: 200px;
        }
    </style>
</head>
<body>
    <div class="container">
    
    <?php
        session_start();
        if(isset($_SESSION['deletemsg'])){
    ?>
        <div class="alert alert-danger"  role="alert">
            <?php 
                echo $_SESSION['deletemsg'];
                unset ($_SESSION['deletemsg']);
            ?>
        </div>
    <?php
        }
        elseif(isset($_SESSION['msg'])){
    ?>
            <div class="alert alert-success" role="alert">
                <?php 
                    echo $_SESSION['msg'];
                    unset ($_SESSION['msg']);
                ?>
            </div>
    <?php
        }
    ?>
    
        <table class="table table-hover table-striped" align="center">
            <thead>
            <tr class="a">
                <td colspan=4 class="p align-middle">Machine Details<br/><a href="formdata.php?a=0" class="btn btn-primary float-right">Add Record</a></td>
                
            </tr>
            <?php
                $q = "
                select 
                    id,machine_name,description 
                from 
                    tbl_machine 
                where 
                    is_delete = 0";
                //echo $q;
                $res=$conn->query($q);
                if($res->num_rows){
            ?>
                    <tr style="height:65px">
                        <th class="align-middle">ID</th>
                        <th class="align-middle">Machine Name</th>
                        <th class="align-middle">Description</th>
                        <th class="align-middle">Action</th>
            
                    </tr>
                </thead>
            <?php
                while($row = $res->fetch_assoc()){
            ?>
                <tr>                            
                    <td class="align-middle"><?=$row['id']?></td>
                    <td class="align-middle"><?=$row['machine_name']?></td>
                    <td class="align-middle"><?=$row['description']?></td>
                    <td class="align-middle">
                        <a href="formdata.php?id=<?=$row['id']?>&a=1" class="btn btn-warning">EDIT</a>&nbsp;
                        <a href="deletedata.php?id=<?=$row['id']?>" class="btn btn-danger"  onclick="return confirm('Are you sure you want to delete?')">DELET</a>
                    </td>
                </tr>
            <?php    
                }
            }else{
            ?>
            <tr>
                    <td colspan="2">No record found.</td>
            </tr>
            <?php
            }
            ?>
        </table>
    </div>
</body>
</html>